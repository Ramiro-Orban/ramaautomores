
function simularFinanciacion() {
    const monto = parseFloat(document.getElementById('monto').value);
    const cuotas = parseInt(document.getElementById('cuotas').value);

    const tasas = {
        18: 0.80,
        36: 0.75,
        48: 0.725
    };

    if (!monto || !cuotas || cuotas <= 0 || !(cuotas in tasas)) {
        document.getElementById('resultado').innerText = "Por favor, ingrese valores válidos.";
        return;
    }

    const tasa = tasas[cuotas];
    const total = monto * Math.pow(1 + tasa, cuotas / 12);
    const cuota = total / cuotas;

    document.getElementById('resultado').innerText = `Cada cuota será de aproximadamente $${cuota.toFixed(2)}.`;
}
